import { CanalEnum } from './canal-enum';

export interface ReportItem {
  razaoSocial: string;
  cnpj: string;
  nrDi: string;
  dtReg: string;
  situacao: string;
  dtSituacao: string;
  urfEntrada: string;
  urfDespacho: string;
  canal: CanalEnum;
  cpfRepresentante: string;
  nomeRepresentante: string;
  vmld: string;
}
