import { Filtro } from './filtro';

describe('Filtro', () => {
  it('should create an instance', () => {
    expect(new Filtro()).toBeTruthy();
  });
});
