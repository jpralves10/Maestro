export interface FiltroServiceItem {
  importer: {
    cpf_cnpj: string;
    name: string;
  };
  representative: {
    cpf_cnpj: string;
    name: string;
  };
  entryUrf: {
    code: string;
    name: string;
  };
  clearanceUrf: {
    code: string;
    name: string;
  };
}
