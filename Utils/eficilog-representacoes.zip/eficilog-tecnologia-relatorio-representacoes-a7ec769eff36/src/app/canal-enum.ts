export enum CanalEnum {
  Verde = 1,
  Amarelo = 2,
  Vermelho = 3,
  Cinza = 4
}
