import { Injectable } from '@angular/core';
import { ReportItem } from './report-item';
import { CanalEnum } from './canal-enum';
import { AuthService } from './auth.service';
import { HttpClient } from '@angular/common/http';

import { Representacoes } from '../types/representacoes';
import { Observable } from 'rxjs';
import { Filter } from 'src/types/filter/filter';

@Injectable({
  providedIn: 'root'
})
export class ReportDataService {
  constructor(
    private authService: AuthService,
    private httpClient: HttpClient
  ) {
    httpClient
      .get(
        'http://relatorios.eficilog.com/api/v1/relatorios/representacoes/filtros'
      )
      .subscribe(data => console.log('resultado request:', data));
  }

  getDadosFiltro(): Observable<Filter> {
    return this.httpClient.get<Filter>(
      'http://relatorios.eficilog.com/api/v1/relatorios/representacoes/filtros'
    );
  }

  getRepresentacoes(filtro: Filter): Observable<Representacoes> {
    const dataPesquisa = new Date();
    dataPesquisa.setMonth(dataPesquisa.getMonth() - 3);
    const strData = dataPesquisa.toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
    return this.httpClient.get<Representacoes>(
      `http://relatorios.eficilog.com/api/v1/relatorios/representacoes?data_inicio=${strData}`
    );
  }
}
