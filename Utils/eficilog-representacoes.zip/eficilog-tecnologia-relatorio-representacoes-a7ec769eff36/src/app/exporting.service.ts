import { Injectable, ElementRef } from '@angular/core';
import * as XLSX from 'xlsx';

import * as jspdf from 'jspdf';

import html2canvas from 'html2canvas';

import * as canvg from 'canvg';

export interface DIReport {
  'Razão Social': string;
  CNPJ: string;
  'Número da DI': string;
  'Data de Registro': string;
  'URF de Entrada': string;
  'URF de Despacho': string;
  Canal: string;
  'CPF do Representante': string;
  'Nome do Representante': string;
  VMLD: string;
}

@Injectable({
  providedIn: 'root'
})
export class ExportingService {
  constructor() {}

  public getImgData(chartContainer: HTMLElement) {
    const chartArea = chartContainer
      .querySelector('iframe')
      .contentDocument.querySelector('svg');
    (window as any).chartArea = chartArea;
    const svg = chartArea.innerHTML;
    const doc = chartContainer.ownerDocument;
    const canvas = doc.createElement('canvas');
    canvas.setAttribute('width', chartArea.clientWidth + '');
    canvas.setAttribute('height', chartArea.clientHeight + '');

    canvas.setAttribute(
      'style',
      'position: absolute; ' +
        'top: ' +
        -chartArea.clientHeight * 2 +
        'px;' +
        'left: ' +
        -chartArea.clientWidth * 2 +
        'px;'
    );
    doc.body.appendChild(canvas);
    canvg.default(canvas, svg);
    const imgData = canvas.toDataURL('image/png');
    canvas.parentNode.removeChild(canvas);
    return imgData;
  }

  public printPDF(element: HTMLElement, img: any) {
    // a4
    // 210mm largura
    // 297mm altura

    (window as any).html2canvas = html2canvas;

    const doc = new jspdf('p', 'px', [2480, 3508] as any);

    const contentWidth = element.clientWidth;
    const contentHeight = element.clientHeight;

    const newWidth = 2480;
    const newHeight = (newWidth * contentHeight) / contentWidth;

    try {
      html2canvas(element, {
        windowWidth: newWidth,
        windowHeight: newHeight,
        allowTaint: true,
        useCORS: true
      }).then(canvas => {
        doc.addImage(canvas.toDataURL('image/png'), 'PNG', 0, 0);

        console.log(img);

        doc.addImage(img.toDataURL('image/png'), 'PNG', 0, 0);
        doc.save('representacoes.pdf');
      });
    } catch (err) {
      const error = err;
    }

    // html2canvas(element).then(canvas => {
    //   const pdf = new jspdf('p', 'mm', 'a4'); // A4 size page of PDF
    //   // pdf.fromHTML(element, 0, 0);
    //   pdf.addHTML(canvas.toDataURL('image/png'), 'PNG', 0, 0, 595, 842);
    //   pdf.save('newPdf.pdf'); // Generated PDF
    // });

    // const data = document.querySelector('#content');
    // html2canvas(data).then(canvas => {
    //   // Few necessary setting options
    //   console.log('Width:', canvas.width, 'Height:', canvas.height);
    //   // const imgWidth = 100;
    //   // const pageHeight = 295;
    //   // const imgHeight = (canvas.height * imgWidth) / canvas.width;
    //   // const heightLeft = imgHeight;
    //   // const contentDataURL = canvas.toDataURL('image/png');

    //   pdf.fromHTML(element, 0, 0);
    //   const position = 0;
    //   // pdf.addImage(contentDataURL, 'PNG', 0, position, imgWidth, imgHeight);

    // });
  }

  public exportAsExcelFile(json: DIReport[], excelFileName: string): void {
    const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(json);
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    XLSX.writeFile(wb, excelFileName);
  }
}
