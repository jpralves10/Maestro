import { MatPaginatorIntl } from '@angular/material';

export class MatPaginatorIntlPtbr extends MatPaginatorIntl {
  itemsPerPageLabel = 'Itens por página';
  nextPageLabel = 'Próxima página';
  previousPageLabel = 'Página anterior';
}
