import { MatPaginatorIntlPtbr } from './mat-paginator-intl-ptbr';

describe('MatPaginatorIntlPtbr', () => {
  it('should create an instance', () => {
    expect(new MatPaginatorIntlPtbr()).toBeTruthy();
  });
});
