import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Representations } from '~/types/report/representations/representations';
import { FilterResultService } from '../../filter/services/filter-result.service';
import { Filter } from '~/types/filter/filter';

export interface TrendData {
  date: Date;
  my: number;
  others: number;
}

export interface FullHonorarios {
  honorarios: HonorariosResult;
  discHonorarios: HonorariosResult;
  valorDesconto: number;
}

export interface HonorariosResult {
  geral: number;
  grupo: number;
  outros: number;
  mediaGeralMensal: number;
  mediaGrupoMensal: number;
  mediaOutrosMensal: number;
}

const emptyHonorariosResult: HonorariosResult = {
  geral: 0,
  grupo: 0,
  outros: 0,
  mediaGeralMensal: 0,
  mediaGrupoMensal: 0,
  mediaOutrosMensal: 0
};

const getDate = (strDate: string): Date => {
  const split = strDate.split('/');

  return new Date(
    parseInt(split[2], 10),
    parseInt(split[1], 10) - 1,
    parseInt(split[0], 10)
  );
};

const daysBetweenDates = (initialDate: Date, finalDate: Date) => {
  const oneDay = 1000 * 60 * 60 * 24;

  const initMs = initialDate.getTime();
  const finalMs = finalDate.getTime();

  return Math.round((finalMs - initMs) / oneDay);
};

const monthDiff = (d1: Date, d2: Date) => {
  let months = 0;
  months = (d2.getFullYear() - d1.getFullYear()) * 12;
  months -= d1.getMonth() + 1;
  months += d2.getMonth();
  return months <= 0 ? 0 : months;
};

@Injectable({
  providedIn: 'root'
})
export class PersistedDataService {
  public Representations: BehaviorSubject<
    Representations
  > = new BehaviorSubject<Representations>(null);

  public representationsValue: Representations = null;

  public filterResult: Filter;

  public getTrendData(representations: Representations): Array<TrendData> {
    if (this.representationsValue === null) {
      return [];
    }

    if (
      this.filterResult.data_inicio === undefined ||
      this.filterResult.data_fim === undefined
    ) {
      return [];
    }

    const initDate = getDate(this.filterResult.data_inicio);
    const endDate = getDate(this.filterResult.data_fim);

    const currentDate = new Date(initDate.getTime());

    const trendData: Array<TrendData> = [];

    while (currentDate <= endDate) {
      trendData.push({
        date: new Date(currentDate.getTime()),
        my: 0,
        others: 0
      });
      currentDate.setDate(currentDate.getDate() + 1);
    }

    const myDeclarations = this.representationsValue.importers.map(
      i => i.my.declarations
    );
    const othersDeclarations = this.representationsValue.importers.map(
      i => i.others.declarations
    );

    console.log(myDeclarations);
    console.log(othersDeclarations);

    myDeclarations.forEach(d => {
      if (d !== undefined) {
        d.forEach(di => {
          const data = trendData.find(
            td => td.date.getTime() === getDate(di.registration).getTime()
          );
          if (data !== undefined) {
            data.my++;
          }
        });
      }
    });

    othersDeclarations.forEach(d => {
      if (d !== undefined) {
        d.forEach(di => {
          const data = trendData.find(
            td => td.date.getTime() === getDate(di.registration).getTime()
          );
          if (data !== undefined) {
            data.others++;
          }
        });
      }
    });

    return trendData;
  }

  public calcHonorarios(value: number, pctDesc: number = 0): FullHonorarios {
    if (this.representationsValue === null) {
      return {
        honorarios: emptyHonorariosResult,
        discHonorarios: emptyHonorariosResult,
        valorDesconto: 0
      };
    }

    let qtdDias = 0;
    let qtdMeses = 1;

    if (
      this.filterResult.data_fim === undefined ||
      this.filterResult.data_inicio === undefined
    ) {
      qtdDias = 0;
    } else {
      qtdDias = daysBetweenDates(
        getDate(this.filterResult.data_inicio),
        getDate(this.filterResult.data_fim)
      );
      qtdMeses =
        monthDiff(
          getDate(this.filterResult.data_inicio),
          getDate(this.filterResult.data_fim)
        ) + 1;
    }

    const rep = this.representationsValue;

    const qtdProcessosTotal =
      rep.my.quantity + rep.others.quantity + rep.both.quantity;

    const qtdProcessosGrupo = rep.my.quantity + rep.both.my.quantity;

    const qtdProcessosOutros = rep.others.quantity + rep.both.others.quantity;

    const discValue = value - (value / 100) * pctDesc;

    const hTotal = qtdProcessosTotal * value;
    const hDiscTotal = qtdProcessosTotal * discValue;

    const hGrupo = qtdProcessosGrupo * value;
    const hDiscGrupo = qtdProcessosGrupo * discValue;

    const hOutros = qtdProcessosOutros * value;
    const hDiscOutros = qtdProcessosOutros * discValue;

    console.log(`quantidade dias: ${qtdDias}, quantidade meses: ${qtdMeses}`);

    const hMediaTotal =
      qtdDias <= 31
        ? (qtdProcessosTotal / (qtdDias * 30)) * value
        : (qtdProcessosTotal / qtdMeses) * value;

    const hMediaTotalDisc =
      qtdDias <= 31
        ? (qtdProcessosTotal / (qtdDias * 30)) * discValue
        : (qtdProcessosTotal / qtdMeses) * discValue;

    const hMediaGrupo =
      qtdDias <= 31
        ? (qtdProcessosGrupo / (qtdDias * 30)) * value
        : (qtdProcessosGrupo / qtdMeses) * value;

    const hMediaGrupoDisc =
      qtdDias <= 31
        ? (qtdProcessosGrupo / (qtdDias * 30)) * discValue
        : (qtdProcessosGrupo / qtdMeses) * discValue;

    const hMediaOutros =
      qtdDias <= 31
        ? (qtdProcessosOutros / (qtdDias * 30)) * value
        : (qtdProcessosOutros / qtdMeses) * value;
    const hMediaOutrosDisc =
      qtdDias <= 31
        ? (qtdProcessosOutros / (qtdDias * 30)) * discValue
        : (qtdProcessosOutros / qtdMeses) * discValue;

    return {
      honorarios: {
        geral: Math.round(hTotal * 100) / 100,
        grupo: Math.round(hGrupo * 100) / 100,
        outros: Math.round(hOutros * 100) / 100,
        mediaGeralMensal: Math.round(hMediaTotal * 100) / 100,
        mediaGrupoMensal: Math.round(hMediaGrupo * 100) / 100,
        mediaOutrosMensal: Math.round(hMediaOutros * 100) / 100
      },
      discHonorarios: {
        geral: Math.round(hDiscTotal * 100) / 100,
        grupo: Math.round(hDiscGrupo * 100) / 100,
        outros: Math.round(hDiscOutros * 100) / 100,
        mediaGeralMensal: Math.round(hMediaTotalDisc * 100) / 100,
        mediaGrupoMensal: Math.round(hMediaGrupoDisc * 100) / 100,
        mediaOutrosMensal: Math.round(hMediaOutrosDisc * 100) / 100
      },
      valorDesconto: pctDesc
    };
  }

  constructor(private filterResultService: FilterResultService) {
    this.Representations.subscribe(r => (this.representationsValue = r));
    this.filterResultService.filterResultSource.subscribe(
      f => (this.filterResult = f)
    );
  }
}
