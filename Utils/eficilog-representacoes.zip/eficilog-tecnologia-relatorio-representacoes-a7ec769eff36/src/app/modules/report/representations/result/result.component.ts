import {
  Component,
  OnInit,
  ViewChild,
  HostListener,
  ElementRef
} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { RepresentationsFilter } from '../representations-filter';
import { DataService } from './services/data.service';
import { Urf } from '~/types/filter/urf';
import { Filter } from '~/types/filter/filter';
import { Representations } from '~/types/report/representations/representations';
import { GoogleChartComponent } from 'angular-google-charts';
import { SankeyDataService } from './services/sankey-data.service';
import { ExportingService, DIReport } from '~/app/exporting.service';
import { ReportItem } from '~/app/report-item';
import { PersistedDataService } from './services/persisted-data.service';

interface PieChartConfig {
  title: string;
  data: Array<Array<any>>;
  options: any;
  onChartClick: (e: Array<{ row: number; column: number }>) => void;
}

interface StackedBarConfig {
  title: string;
  data: Array<Array<any>>;
  options: any;
  columnNames: string[];
}

const getTransformedData = (data: any): Representations => {
  return {
    my: data.my,
    both: data.both,
    importers: Object.keys(data.importers).map(key => ({
      id: key,
      ...data.importers[key]
    })),
    clearance_urfs: Object.keys(data.clearance_urfs).map(key => ({
      id: key,
      ...data.clearance_urfs[key]
    })),
    others: data.others
  };
};

@Component({
  selector: 'app-result',
  templateUrl: './result.component.html',
  styleUrls: ['./result.component.scss']
})
export class ResultComponent implements OnInit {
  @ViewChild('chartRepresentations')
  chartRepresentations: GoogleChartComponent;

  @ViewChild('chartUrfsByQuantity')
  chartUrfsByQuantity: any;

  @ViewChild('chartUrfsByValue')
  chartUrfsByValue: any;

  @ViewChild('content')
  content: ElementRef;

  public filter: RepresentationsFilter;
  public loading = true;
  public errored = false;
  public representations: Representations;

  public filterContent: Filter;

  public Urfs: Urf[];

  public ChartWidth = 500;

  public ChartRepresentacoes: PieChartConfig = {
    title: 'Geral',
    data: [],
    options: {
      animation: {
        duration: 1000,
        easing: 'in'
      },
      redrawTrigger: 0
    },
    onChartClick: e => {
      if (this.ChartRepresentacoes.title === 'Compartilhado') {
        this.renderChartRepresentacoes();
      } else {
        if (e.length > 0 && e[0].row === 2) {
          this.renderChartRepresentacoes(1);
        }
      }
    }
  };

  public ChartUrfsQuantity: StackedBarConfig = {
    title: 'Quantidade por URF',
    columnNames: ['URF', 'Pelo grupo', 'Por outros'],
    data: [],
    options: {
      isStacked: true,
      legend: { position: 'top', maxLines: 3 },
      hAxis: {
        textStyle: {
          fontSize: 10 // or the number you want
        }
      }
    }
  };

  public ChartUrfsValue: StackedBarConfig = {
    title: 'Valor por URF',
    columnNames: ['URF', 'Pelo grupo', 'Por outros'],
    data: [],
    options: {
      isStacked: true,
      legend: { position: 'top', maxLines: 3 },
      hAxis: {
        textStyle: {
          fontSize: 10 // or the number you want
        }
      }
    }
  };

  public ChartSankey = {
    columnNames: ['De', 'Para', 'Quantidade de DIs'],
    data: []
  };

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private dataService: DataService,
    private sankeyData: SankeyDataService,
    private exportingService: ExportingService,
    private persistedData: PersistedDataService
  ) {
    this.route.queryParamMap.subscribe(paramMap => {
      this.filter = JSON.parse(paramMap.get('filter'));
    });
  }

  @HostListener('window:resize', ['$event'])
  onWindowResize(event: any) {
    this.ChartRepresentacoes.options.redrawTrigger++;
  }

  public exportExcel() {
    this.exportingService.exportAsExcelFile(
      this.sankeyData.excelDataFromRepresentations(this.representations),
      this.representations.importers.length > 1
        ? `estudo-logistico-${this.representations.importers.length}cnpjs.xlsx`
        : `estudo-logistico-${
            this.sankeyData.getImporterById(
              this.representations.importers[0].id
            ).name
          }.xlsx`
    );
  }

  public exportPDF() {
    const container = document.querySelector('#sankey-diagram-ncms');

    const img = this.exportingService.getImgData(container as HTMLElement);
    this.exportingService.printPDF(this.content.nativeElement, img);
  }

  public renderChartRepresentacoes(type: number = 0) {
    if (type === 0) {
      this.ChartRepresentacoes.data = [
        ['Pelo grupo', this.representations.my.quantity],
        ['Por outros', this.representations.others.quantity],
        ['Compartilhado', this.representations.both.quantity]
      ];
      this.ChartRepresentacoes.title = 'Geral';
    } else if (type === 1) {
      this.ChartRepresentacoes.data = [
        ['Pelo grupo', this.representations.both.my.quantity],
        ['Por outros', this.representations.both.others.quantity]
      ];
      this.ChartRepresentacoes.title = 'Compartilhado';
    }
  }

  public renderChartsUrfs() {
    this.ChartUrfsQuantity.data = this.representations.clearance_urfs
      .sort(
        (urf1, urf2) =>
          urf2.my.quantity +
          urf2.others.quantity -
          (urf1.my.quantity + urf1.others.quantity)
      )
      .map(urf => {
        const urfFound = this.filterContent.clearance_urfs.find(item => {
          return +item.id === +urf.id;
        });

        return [urfFound.name, urf.my.quantity, urf.others.quantity];
      });

    console.log(this.ChartUrfsQuantity);

    this.ChartUrfsValue.data = this.representations.clearance_urfs
      .sort(
        (urf1, urf2) =>
          urf2.my.value +
          urf2.others.value -
          (urf1.my.value + urf1.others.value)
      )
      .map(urf => {
        const urfFound = this.filterContent.clearance_urfs.find(item => {
          return +item.id === +urf.id;
        });
        return [
          urfFound.name,
          Math.round(urf.my.value * 100) / 100,
          Math.round(urf.others.value * 100) / 100
        ];
      });
  }

  public initialLoadData() {
    this.renderChartRepresentacoes();
    this.renderChartsUrfs();
    this.sankeyData.loadData(this.representations);
  }

  ngOnInit() {
    const filterContent = window.sessionStorage.getItem('filter');
    if (filterContent === null) {
      this.router.navigate(['../'], { relativeTo: this.route });
      return;
    }

    this.filterContent = JSON.parse(filterContent);

    this.sankeyData.loadFilter(this.filterContent);

    // const currentRepresentations = window.sessionStorage.getItem(
    //   'representations'
    // );
    const currentRepresentations = null;
    if (currentRepresentations !== null && currentRepresentations !== '') {
      this.representations = JSON.parse(currentRepresentations);
      this.loading = false;
      this.errored = false;
      this.initialLoadData();
      return;
    } else {
      this.dataService
        .getData(this.filter)
        // .pipe(
        //   map(res => res),
        //   catchError(error => throwError(error))
        .subscribe(
          result => {
            this.representations = getTransformedData(result);
            this.persistedData.Representations.next(this.representations);
            this.loading = false;
            this.errored = false;
            // window.sessionStorage.setItem(
            //   'representations',
            //   JSON.stringify(this.representations)
            // );
            this.initialLoadData();
          },
          err => console.log(err),
          () => console.log('completed')
        );
    }
  }
}
