import { Component, OnInit } from '@angular/core';
import { PersistedDataService } from '../services/persisted-data.service';

export interface TrendlineChart {
  options: any;
  columnNames: Array<any>;
  data: Array<Array<any>>;
}

@Component({
  selector: 'app-trendline-chart',
  templateUrl: './trendline-chart.component.html',
  styleUrls: ['./trendline-chart.component.scss']
})
export class TrendlineChartComponent implements OnInit {
  public Chart: TrendlineChart = {
    options: {
      trendlines: {
        0: {},
        1: {}
      },
      hAxis: {
        format: 'dd/MM/yyyy'
      }
    },
    columnNames: ['Data', 'Do grupo', 'De outros'],
    data: []
  };

  constructor(private persistedData: PersistedDataService) {
    this.persistedData.Representations.subscribe(r => {
      const data = this.persistedData.getTrendData(r);
      this.Chart.data = [];

      if (data === undefined) {
        return;
      }

      data.forEach(d => {
        if (d.my > 0 || d.others > 0) {
          this.Chart.data.push([d.date, d.my, d.others]);
        }
      });
    });
  }

  ngOnInit() {}
}
