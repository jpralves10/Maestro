import { TestBed } from '@angular/core/testing';

import { FilterResultService } from './filter-result.service';

describe('FilterResultService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: FilterResultService = TestBed.get(FilterResultService);
    expect(service).toBeTruthy();
  });
});
