import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { Representative } from '~/types/filter/representative';
import { MatPaginator, MatSort } from '@angular/material';
import { RepresentativesListDataSource } from './representatives-list-datasource';
import { SelectionModel } from '@angular/cdk/collections';
import { FilterItem } from '../filter-item.type';
import { FilterService } from '../services/filter.service';
import { FilterResultService } from '../services/filter-result.service';
import { Filter } from '~/types/filter/filter';

@Component({
  selector: 'app-representatives-list',
  templateUrl: './representatives-list.component.html',
  styleUrls: ['./representatives-list.component.scss']
})
export class RepresentativesListComponent implements OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  dataSource: RepresentativesListDataSource;

  selection = new SelectionModel<Representative>(true, []);

  @Input()
  data: Representative[];

  /** Columns displayed in the table. Columns IDs can be added, removed, or reordered. */
  displayedColumns = ['select', 'name', 'cpf_cnpj'];

  public filtroValue: FilterItem;

  public currentFilter: Filter;

  constructor(
    private filterService: FilterService,
    private filterResultService: FilterResultService
  ) {
    filterService.filter.subscribe(f => (this.filtroValue = f));

    filterResultService.filterResult.subscribe(fr => (this.currentFilter = fr));
    this.selection.changed.subscribe(() => {
      filterResultService.changeFilterResult({
        ...this.currentFilter,
        representatives: this.selection.selected
      });
    });
  }

  deselectAll() {
    this.selection.clear();
    this.paginator.firstPage();
  }

  getVisibleData() {
    return this.dataSource.getUpdatedData();
  }

  isAllSelected() {
    const visibleData = this.dataSource.getUpdatedData();
    return !visibleData.some(
      ds => !this.selection.selected.some(s => s.cpf_cnpj === ds.cpf_cnpj)
    );
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    const visibleData = this.getVisibleData();
    const allSelected = this.isAllSelected();

    if (allSelected) {
      this.selection.deselect(...visibleData);
    } else {
      this.selection.select(...visibleData);
    }

    // (await this.isAllSelected())
    //   ? this.selection.clear()
    //   : this.dataSource.data.forEach(row => this.selection.select(row));
    return;
  }

  // tslint:disable-next-line:use-life-cycle-interface
  ngAfterViewInit() {
    this.filterService.whenUpdatedSource.next([
      ...this.filterService.whenUpdated,
      this.paginator
    ]);
  }

  ngOnInit() {
    this.dataSource = new RepresentativesListDataSource(
      this.paginator,
      this.sort,
      this.filterService,
      this.data
    );
  }
}
