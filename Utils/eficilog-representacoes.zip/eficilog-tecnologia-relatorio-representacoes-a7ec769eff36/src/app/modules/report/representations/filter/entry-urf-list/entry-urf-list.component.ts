import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { MatPaginator, MatSort } from '@angular/material';
import { EntryUrfListDataSource } from './entry-urf-list-datasource';
import { SelectionModel } from '@angular/cdk/collections';
import { Urf } from '~/types/filter/urf';
import { FilterItem } from '../filter-item.type';
import { FilterService } from '../services/filter.service';
import { Filter } from '~/types/filter/filter';
import { FilterResultService } from '../services/filter-result.service';

@Component({
  selector: 'app-entry-urf-list',
  templateUrl: './entry-urf-list.component.html',
  styleUrls: ['./entry-urf-list.component.scss']
})
export class EntryUrfListComponent implements OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  dataSource: EntryUrfListDataSource;

  selection = new SelectionModel<Urf>(true, []);

  @Input()
  data: Urf[];

  /** Columns displayed in the table. Columns IDs can be added, removed, or reordered. */
  displayedColumns = ['select', 'code', 'name'];

  public filtroValue: FilterItem;

  public currentFilter: Filter;

  constructor(
    private filterService: FilterService,
    private filterResultService: FilterResultService
  ) {
    filterService.filter.subscribe(f => (this.filtroValue = f));

    filterResultService.filterResult.subscribe(fr => (this.currentFilter = fr));
    this.selection.changed.subscribe(() => {
      filterResultService.changeFilterResult({
        ...this.currentFilter,
        entry_urfs: this.selection.selected
      });
    });
  }

  deselectAll() {
    this.selection.clear();
    this.paginator.firstPage();
  }

  getVisibleData() {
    return this.dataSource.getUpdatedData();
  }

  isAllSelected() {
    const visibleData = this.dataSource.getUpdatedData();
    return !visibleData.some(
      ds => !this.selection.selected.some(s => s.code === ds.code)
    );

    // const numSelected = this.selection.selected.length;
    // const numRows = this.dataSource.data.length;
    // return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    const visibleData = this.getVisibleData();
    const allSelected = this.isAllSelected();

    if (allSelected) {
      this.selection.deselect(...visibleData);
    } else {
      this.selection.select(...visibleData);
    }

    // (await this.isAllSelected())
    //   ? this.selection.clear()
    //   : this.dataSource.data.forEach(row => this.selection.select(row));
    return;
  }

  // tslint:disable-next-line:use-life-cycle-interface
  ngAfterViewInit() {
    this.filterService.whenUpdatedSource.next([
      ...this.filterService.whenUpdated,
      this.paginator
    ]);
  }

  ngOnInit() {
    this.dataSource = new EntryUrfListDataSource(
      this.paginator,
      this.sort,
      this.filterService,
      this.data
    );
  }
}
