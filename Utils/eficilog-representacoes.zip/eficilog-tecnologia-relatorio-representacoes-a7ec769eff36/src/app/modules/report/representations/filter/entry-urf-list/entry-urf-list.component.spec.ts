import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EntryUrfListComponent } from './entry-urf-list.component';

describe('EntryUrfListComponent', () => {
  let component: EntryUrfListComponent;
  let fixture: ComponentFixture<EntryUrfListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EntryUrfListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EntryUrfListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
