import { Component, OnInit, Input } from '@angular/core';
import {
  PersistedDataService,
  FullHonorarios
} from '../services/persisted-data.service';

@Component({
  selector: 'app-honorarios',
  templateUrl: './honorarios.component.html',
  styleUrls: ['./honorarios.component.scss']
})
export class HonorariosComponent implements OnInit {
  @Input()
  public valorHonorarios = '0';

  @Input()
  public descHonorarios = '0';

  public honorarios: FullHonorarios = {
    discHonorarios: {
      geral: 0,
      grupo: 0,
      mediaGeralMensal: 0,
      mediaGrupoMensal: 0,
      mediaOutrosMensal: 0,
      outros: 0
    },
    honorarios: {
      geral: 0,
      grupo: 0,
      mediaGeralMensal: 0,
      mediaGrupoMensal: 0,
      mediaOutrosMensal: 0,
      outros: 0
    },
    valorDesconto: 0
  };

  public formattedNumber(num: number): string {
    return num.toLocaleString('pt-br', { style: 'currency', currency: 'BRL' });
  }

  constructor(private persistedData: PersistedDataService) {}

  public updateHonorarios() {
    this.valorHonorarios = this.valorHonorarios.replace(/[^\d]+/g, '');
    this.descHonorarios = this.descHonorarios.replace(/[^\d]+/g, '');

    const valorHonorarios =
      this.valorHonorarios === '' || this.valorHonorarios === undefined
        ? 0
        : parseInt(this.valorHonorarios, 10);
    const descHonorarios =
      this.descHonorarios === '' || this.descHonorarios === undefined
        ? 0
        : parseInt(this.descHonorarios, 10);

    this.honorarios = this.persistedData.calcHonorarios(
      valorHonorarios,
      descHonorarios
    );

    console.log(this.honorarios);
  }

  ngOnInit() {}
}
