import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FilterComponent } from './filter/filter.component';
import { ImportersListComponent } from './filter/importers-list/importers-list.component';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { RepresentativesListComponent } from './filter/representatives-list/representatives-list.component';
import { EntryUrfListComponent } from './filter/entry-urf-list/entry-urf-list.component';
import { ClearanceUrfListComponent } from './filter/clearance-urf-list/clearance-urf-list.component';
import { MaterialModule } from '~/app/material/material.module';
import { ResultComponent } from './result/result.component';
import { GoogleChartsModule } from 'angular-google-charts';
import { MatInputModule } from '@angular/material';

import { REPRESENTATIONS_ROUTES } from './representations.routes';
import { SankeyComponent } from './result/sankey/sankey.component';
import { HonorariosComponent } from './result/honorarios/honorarios.component';
import { TrendlineChartComponent } from './result/trendline-chart/trendline-chart.component';

@NgModule({
  declarations: [
    FilterComponent,
    ImportersListComponent,
    RepresentativesListComponent,
    EntryUrfListComponent,
    ClearanceUrfListComponent,
    ResultComponent,
    SankeyComponent,
    HonorariosComponent,
    TrendlineChartComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    MaterialModule,
    MatInputModule,
    RouterModule.forChild(REPRESENTATIONS_ROUTES),
    GoogleChartsModule.forRoot()
  ]
})
export class RepresentationsModule {}
