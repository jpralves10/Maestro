export interface ChannelItem {
  name: string;
  amount: number;
}

export interface DispatchUrfItem {
  name: string;
  amount: number;
  channels: ChannelItem[];
}

export interface EntryUrfItem {
  name: string;
  amount: number;
  dispatchUrfs: DispatchUrfItem[];
}

export interface RepresentativeItem {
  name: string;
  amount: number;
  entryUrfs: EntryUrfItem[];
}

export interface CountryItem {
  name: string;
  amount: number;
  representatives: RepresentativeItem[];
}

export interface NcmItem {
  name: string;
  countries: CountryItem[];
  declarations: number;
  relevance: number;
}

export interface NcmList {
  my: NcmItem[];
  others: NcmItem[];
}

export interface SankeyData {
  ncms: NcmList;
}
