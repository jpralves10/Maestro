import { Injectable } from '@angular/core';
import {
  Representations,
  Declaration
} from '~/types/report/representations/representations';
import { NcmItem, NcmList } from './sankey-item.type';
import { Filter } from '~/types/filter/filter';
import { FilterService, SankeyFilter } from '../sankey/services/filter.service';
import { ImportersListComponent } from '../../filter/importers-list/importers-list.component';
import { DIReport } from '~/app/exporting.service';

const channels = {
  '000': 'SEM PARAMETRIZAÇÃO',
  '001': 'VERDE',
  '002': 'AMARELO',
  '003': 'VERMELHO',
  '004': 'CINZA'
};

@Injectable({
  providedIn: 'root'
})
export class SankeyDataService {
  public filterList: Filter;

  public sankeyFilter: SankeyFilter;

  public totalDeclarations: number;

  public ncmList: NcmList;

  public filteredNcms: NcmItem[] = [];

  constructor(private filterService: FilterService) {
    filterService.filter.subscribe(filter => {
      this.sankeyFilter = filter;
    });
  }

  // public updateFilter() {
  //   console.log('filtering');

  //   const filter = this.sankeyFilter;
  //   this.filteredNcms = this.ncms.filter(ncm => {
  //     let ok = true;
  //     if (filter.code !== '') {
  //       ok = ncm.name.startsWith(filter.code);
  //     }
  //     if (!ok) {
  //       return false;
  //     }
  //     if (filter.relevance_direction === 'Maior') {
  //       ok = ncm.relevance >= filter.relevance;
  //     } else {
  //       ok = ncm.relevance <= filter.relevance;
  //     }
  //     return ok;
  //   });
  // }

  public getImporterById(importer_id: number) {
    return this.filterList.importers.find(
      importer => +importer.id === +importer_id
    );
  }

  public getRepresentativeById(representative_id: number) {
    return this.filterList.representatives.find(
      rep => +rep.id === +representative_id
    );
  }

  public getEntryUrfById(urf_id: number) {
    return this.filterList.entry_urfs.find(urf => +urf.id === +urf_id);
  }

  public getClearanceUrf(urf_id: number) {
    return this.filterList.clearance_urfs.find(urf => +urf.id === urf_id);
  }

  public loadFilter(filter: Filter) {
    this.filterList = filter;
  }

  public dissectData(declarations: Declaration[]) {
    const ncms: NcmItem[] = [];

    declarations.forEach(declaration => {
      declaration.ncms.forEach(ncm => {
        let ncmFromList = ncms.find(ncmItem => ncmItem.name === ncm.code);

        if (ncmFromList === undefined) {
          ncmFromList = {
            name: ncm.code,
            countries: [],
            relevance: 0,
            declarations: 0
          };
          ncms.push(ncmFromList);
        }
        ncmFromList.declarations++;

        let countryFromList = ncmFromList.countries.find(
          c => c.name === ncm.country
        );

        if (countryFromList === undefined) {
          countryFromList = {
            name: ncm.country,
            amount: 0,
            representatives: []
          };
          ncmFromList.countries.push(countryFromList);
        }
        countryFromList.amount++;

        const representativeName = this.getRepresentativeById(
          declaration.representative_id
        ).name;
        let representativeFromList = countryFromList.representatives.find(
          r => r.name === representativeName
        );

        if (representativeFromList === undefined) {
          representativeFromList = {
            name: representativeName,
            amount: 0,
            entryUrfs: []
          };
          countryFromList.representatives.push(representativeFromList);
        }
        representativeFromList.amount++;

        const entryUrfName = this.getEntryUrfById(declaration.entry_urf_id)
          .name;
        let entryUrfFromList = representativeFromList.entryUrfs.find(
          urf => urf.name === entryUrfName
        );

        if (entryUrfFromList === undefined) {
          entryUrfFromList = {
            name: entryUrfName,
            amount: 0,
            dispatchUrfs: []
          };
          representativeFromList.entryUrfs.push(entryUrfFromList);
        }
        entryUrfFromList.amount++;

        const clearanceUrfName = this.getClearanceUrf(
          declaration.clearance_urf_id
        ).name;
        let clearanceUrfFromList = entryUrfFromList.dispatchUrfs.find(
          urf => urf.name === clearanceUrfName
        );

        if (clearanceUrfFromList === undefined) {
          clearanceUrfFromList = {
            name: clearanceUrfName,
            amount: 0,
            channels: []
          };
          entryUrfFromList.dispatchUrfs.push(clearanceUrfFromList);
        }
        clearanceUrfFromList.amount++;

        const channelName = declaration.selection_channel;
        let channelFromList = clearanceUrfFromList.channels.find(
          ch => ch.name === channelName
        );

        if (!channelFromList) {
          channelFromList = {
            name: channelName,
            amount: 0
          };
          clearanceUrfFromList.channels.push(channelFromList);
        }
        channelFromList.amount++;
      });
    });

    return ncms;
  }

  public loadData(representations: Representations) {
    let myDeclarations: Declaration[] = [];
    let othersDeclarations: Declaration[] = [];

    representations.importers.forEach(importer => {
      if (importer.my.declarations !== undefined) {
        myDeclarations = myDeclarations.concat(
          JSON.parse(JSON.stringify(importer.my.declarations))
        );
      }

      if (importer.others.declarations !== undefined) {
        othersDeclarations = othersDeclarations.concat(
          JSON.parse(JSON.stringify(importer.others.declarations))
        );
      }
    });

    const ncmList: NcmList = {
      my: this.dissectData(myDeclarations),
      others: this.dissectData(othersDeclarations)
    };

    this.ncmList = ncmList;

    // this.totalDeclarations = ncms
    //   .map(ncm => ncm.declarations)
    //   .reduce((a, b) => a + b);

    // ncms.forEach(ncm => {
    //   ncm.relevance = (ncm.declarations / this.totalDeclarations) * 100;
    // });
  }

  public excelDataFromRepresentations(representations: Representations) {
    const lista: DIReport[] = [];

    representations.importers.forEach(importer => {
      let declarations: Declaration[] = [];

      if (importer.my.declarations !== undefined) {
        declarations = declarations.concat(importer.my.declarations);
      }

      if (importer.others.declarations !== undefined) {
        declarations = declarations.concat(importer.others.declarations);
      }

      declarations.forEach(di => {
        const representative = this.getRepresentativeById(di.representative_id);
        const imp = this.getImporterById(importer.id);
        const urfEntrada = this.getEntryUrfById(di.entry_urf_id);
        const urfDespacho = this.getClearanceUrf(di.clearance_urf_id);
        lista.push({
          'Número da DI': di.number,
          'Data de Registro': di.registration,
          'Razão Social': imp.name,
          CNPJ: imp.cpf_cnpj,
          'CPF do Representante': representative.cpf_cnpj,
          'Nome do Representante': representative.name,
          'URF de Entrada': urfEntrada.name,
          'URF de Despacho': urfDespacho.name,
          Canal: channels[di.selection_channel],
          VMLD: di.discharge_dollar_value + ''
        });
      });
    });

    return lista;
  }
}
