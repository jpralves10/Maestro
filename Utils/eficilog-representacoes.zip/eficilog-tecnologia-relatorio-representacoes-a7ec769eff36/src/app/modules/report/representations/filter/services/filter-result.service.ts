import { Injectable } from '@angular/core';
import { Filter } from '~/types/filter/filter';
import { BehaviorSubject, Observable } from 'rxjs';
import * as DateManagement from '~/app/utils/date-management';

const actualDateDecremented = (): Date => {
  const actualDate = new Date();
  actualDate.setMonth(actualDate.getMonth() - 3);
  return actualDate;
};

@Injectable({
  providedIn: 'root'
})
export class FilterResultService {
  private readonly defaultFilter: Filter = {
    importers: [],
    representatives: [],
    entry_urfs: [],
    clearance_urfs: [],
    data_inicio: DateManagement.BrFormatDateFromDate(actualDateDecremented()),
    data_fim: DateManagement.BrFormatDateFromDate(new Date())
  };

  public filterResultSource: BehaviorSubject<Filter> = new BehaviorSubject<
    Filter
  >(this.defaultFilter);

  public filterResult: Observable<
    Filter
  > = this.filterResultSource.asObservable();

  public changeFilterResult(filter: Filter) {
    this.filterResultSource.next(filter);
  }

  public resetFilter() {
    this.filterResultSource.next(this.defaultFilter);
  }

  constructor() {}
}
