import { TestBed } from '@angular/core/testing';

import { SankeyDataService } from './sankey-data.service';

describe('SankeyDataService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SankeyDataService = TestBed.get(SankeyDataService);
    expect(service).toBeTruthy();
  });
});
