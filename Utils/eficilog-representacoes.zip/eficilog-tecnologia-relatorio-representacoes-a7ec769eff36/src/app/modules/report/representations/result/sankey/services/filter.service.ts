import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

export interface SankeyFilter {
  code: string;
  relevance_direction: 'Menor' | 'Maior';
  relevance: number;
  representation: 'Todos' | 'Grupo' | 'Outros';
}

@Injectable({
  providedIn: 'root'
})
export class FilterService {
  public filterSource: BehaviorSubject<SankeyFilter> = new BehaviorSubject<
    SankeyFilter
  >({
    code: '',
    relevance: 0,
    relevance_direction: 'Maior',
    representation: 'Grupo'
  });

  public filter = this.filterSource.asObservable();

  public code = '';
  public relevance_direction: 'Menor' | 'Maior' = 'Maior';
  public relevance = 50;
  public representation: 'Todos' | 'Grupo' | 'Outros';

  constructor() {}

  public changeFilter(filter: SankeyFilter) {
    if (isNaN(filter.relevance)) {
      filter.relevance = 0;
    }
    this.filterSource.next(filter);
  }
}
