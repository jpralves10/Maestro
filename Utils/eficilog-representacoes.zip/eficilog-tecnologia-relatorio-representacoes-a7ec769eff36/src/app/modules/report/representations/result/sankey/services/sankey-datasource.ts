import { DataSource } from '@angular/cdk/table';
import { NcmItem, NcmList } from '../../services/sankey-item.type';
import { MatPaginator } from '@angular/material';
import { FilterService, SankeyFilter } from './filter.service';
import { Input } from '@angular/core';
import { Observable, merge, of as observableOf } from 'rxjs';
import { map } from 'rxjs/operators';

export class SankeyDataSource extends DataSource<NcmItem> {
  private readonly defaultNcmList: NcmList = {
    my: [],
    others: []
  };

  @Input()
  public data: NcmList = this.defaultNcmList;
  public fullData: NcmList = this.defaultNcmList;
  public filteredData: NcmItem[] = [];

  public paginator: MatPaginator;

  public filtro: SankeyFilter;

  constructor(private filterService: FilterService, data: NcmList) {
    super();
    this.data = data;
    this.fullData = { ...data };
    this.filterService.filterSource.subscribe(filtro => (this.filtro = filtro));
  }

  /**
   * Connect this data source to the table. The table will only update when
   * the returned stream emits new items.
   * @returns A stream of the items to be rendered.
   */
  connect(): Observable<NcmItem[]> {
    // Combine everything that affects the rendered data into one update
    // stream for the data-table to consume.
    const dataMutations = [
      observableOf(this.data),
      this.filterService.filterSource,
      this.paginator.page
    ];

    // Set the paginator's length
    // this.paginator.length = this.data.length;

    return merge(...dataMutations).pipe(map(() => this.getUpdatedData()));
  }

  public getUpdatedData() {
    const data = this.getFilteredData(this.fullData);

    console.log('getUpdatedData..filteredData:', data);

    this.paginator.length = data.length;

    this.filteredData = [...data];

    const newData = this.getPagedData(data);

    console.log('getUpdatedData..pagedData:', newData);

    return newData;
  }

  /**
   *  Called when the table is being destroyed. Use this function, to clean up
   * any open connections or free any held resources that were set up during connect.
   */
  disconnect() {}

  public getFilteredData(data: NcmList): NcmItem[] {
    const {
      code,
      relevance,
      relevance_direction,
      representation
    } = this.filtro;

    let newData: NcmItem[] = [];

    if (representation === 'Grupo') {
      newData = data.my;
    } else if (representation === 'Outros') {
      newData = data.others;
    }

    if (code !== '') {
      newData = newData.filter(d => d.name.startsWith(code));
    }

    if (newData.length === 0) {
      return [];
    }

    const totalDeclarations = newData
      .map(ncm => ncm.declarations)
      .reduce((a, b) => a + b);

    newData.forEach(ncm => {
      ncm.relevance = (ncm.declarations / totalDeclarations) * 100;
    });

    newData = newData.filter(ncm => {
      return relevance_direction === 'Maior'
        ? ncm.relevance >= relevance
        : ncm.relevance <= relevance;
    });

    newData = newData.sort((a, b) => b.declarations - a.declarations);

    return newData;
  }

  /**
   * Paginate the data (client-side). If you're using server-side pagination,
   * this would be replaced by requesting the appropriate data from the server.
   */
  public getPagedData(data: NcmItem[]) {
    if (this.paginator.pageSize === undefined) {
      this.paginator.pageSize = 20;
    }

    const startIndex = this.paginator.pageIndex * this.paginator.pageSize;

    return [...[...data].splice(startIndex, this.paginator.pageSize)];
  }
}
