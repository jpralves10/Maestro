import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { FilterService, SankeyFilter } from './services/filter.service';
import { tryParse } from 'selenium-webdriver/http';
import { SankeyDataService } from '../services/sankey-data.service';
import { NcmItem, NcmList } from '../services/sankey-item.type';
import { SankeyDataSource } from './services/sankey-datasource';
import { MatPaginator } from '@angular/material';
import { of } from 'rxjs';
import { Filter } from '~/types/filter/filter';
import { Representations } from '~/types/report/representations/representations';
import { PersistedDataService } from '../services/persisted-data.service';

const channels = {
  '000': 'SEM PARAMETRIZAÇÃO',
  '001': 'VERDE',
  '002': 'AMARELO',
  '003': 'VERMELHO',
  '004': 'CINZA'
};

@Component({
  selector: 'app-sankey',
  templateUrl: './sankey.component.html',
  styleUrls: ['./sankey.component.scss']
})
export class SankeyComponent implements OnInit {
  constructor(
    private filterService: FilterService,
    private persistedData: PersistedDataService
  ) {}

  @ViewChild(MatPaginator) paginator: MatPaginator;

  @Input()
  public data: NcmList;

  private dataSource: SankeyDataSource;

  public filter: SankeyFilter;

  public filteredData: NcmItem[];

  public resultadoHonorarios = -1;

  public representations: Representations;

  public ChartSankey = {
    columnNames: ['De', 'Para', 'Quantidade de DIs'],
    data: [],
    options: {
      forceIFrame: true,
      sankey: {
        link: {
          colorMode: 'gradient'
        },
        node: {
          colorMode: 'unique',
          width: 5
        }
        // iterations: 0
      }
    }
  };

  public code: string;
  public relevance: number;
  public relevance_direction: 'Menor' | 'Maior';
  public representation: 'Todos' | 'Grupo' | 'Outros';

  public changeRelevance(value: any) {
    if (value === '') {
      this.updateLocal();
      return;
    }

    let newRelevance = 50;

    try {
      const relevance = parseInt(value, 10);
      if (relevance > 100) {
        newRelevance = 100;
      } else if (relevance < 0) {
        newRelevance = 0;
      } else {
        newRelevance = relevance;
      }
      this.filterService.changeFilter({
        ...this.filter,
        relevance: newRelevance
      });
    } catch (err) {
      this.updateLocal();
    }

    this.updateLocal();
  }

  public onKeyDownLimit(event: any, maxLength: number) {
    console.log(event);
    if (
      event.target.value.length >= maxLength &&
      event.key !== 'Backspace' &&
      event.key !== 'Delete'
    ) {
      event.preventDefault();
      return false;
    }
  }

  public changeRepresentation(representation: 'Todos' | 'Grupo' | 'Outros') {
    this.filterService.changeFilter({
      ...this.filter,
      representation
    });
  }

  public changeRelevanceDirection(direction: 'Menor' | 'Maior') {
    console.log('relevance direction changed:', direction);
    this.filterService.changeFilter({
      ...this.filter,
      relevance_direction: direction
    });
  }

  public changeCode(code: string) {
    console.log('code changed:', code);
    this.filterService.changeFilter({ ...this.filter, code });
  }

  public updateFilter() {
    console.log('updateFilter() called');

    if (this.code === null) {
      this.code = '';
    }
    this.filter.code = this.code;

    this.filterService.changeFilter(this.filter);
  }

  public updateLocal() {
    this.code = this.filter.code;
    this.relevance = this.filter.relevance;
    this.relevance_direction = this.filter.relevance_direction;

    this.paginator.firstPage();
  }

  public renderChartSankey() {
    const data: Array<Array<any>> = [];

    if (this.filteredData === undefined) {
      this.data = { my: [], others: [] };
      return;
    }

    this.filteredData.forEach(ncm => {
      ncm.countries.forEach(c => {
        data.push([ncm.name, c.name, c.amount]);
        c.representatives.forEach(r => {
          data.push([c.name, r.name, r.amount]);
          r.entryUrfs.forEach(entryUrf => {
            data.push([r.name, entryUrf.name, entryUrf.amount]);
            entryUrf.dispatchUrfs.forEach(clearanceUrf => {
              data.push([
                entryUrf.name,
                ' ' + clearanceUrf.name,
                clearanceUrf.amount
              ]);
              clearanceUrf.channels.forEach(channel => {
                data.push([
                  ' ' + clearanceUrf.name,
                  channels[channel.name],
                  channel.amount
                ]);
              });
            });
          });
        });
      });
    });

    const newData: Array<Array<any>> = [];

    data.forEach(d => {
      const existing = newData.find(nd => nd[0] === d[0] && nd[1] === d[1]);
      if (existing !== undefined) {
        existing[2] += d[2];
      } else {
        newData.push(d);
      }
    });

    console.log(newData);

    this.ChartSankey.data = newData;
  }

  // tslint:disable-next-line:use-life-cycle-interface
  ngAfterViewInit() {}

  ngOnInit() {
    this.persistedData.Representations.subscribe(
      r => (this.representations = r)
    );

    setTimeout(() => {
      this.dataSource = new SankeyDataSource(this.filterService, this.data);
      this.dataSource.paginator = this.paginator;

      this.dataSource.connect().subscribe(ncms => {
        this.filteredData = ncms;

        // if (this.filter.representation === 'Outros') {
        //   if (this.representations !== null) {
        //     const ncmsOfFilter = this.representations.importers
        //     this.resultadoHonorarios = this.representations.importers.map(i => i.others.)
        //   }
        // }

        setTimeout(() => {
          this.renderChartSankey();
        });
      });
    });
    this.filterService.filter.subscribe(f => {
      this.filter = f;
      this.updateLocal();
    });
  }
}
