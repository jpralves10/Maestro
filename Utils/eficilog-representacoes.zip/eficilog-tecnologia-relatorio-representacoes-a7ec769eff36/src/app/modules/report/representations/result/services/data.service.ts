import { Injectable } from '@angular/core';
import { RepresentationsFilter } from '../../representations-filter';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

const BASE_URL =
  'http://relatorios.eficilog.com/api/v1/relatorios/representacoes';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  constructor(private httpClient: HttpClient) {}

  public getData(filter: RepresentationsFilter): Observable<any> {
    let requestUrl = BASE_URL + '?';
    if (filter.importers.length > 0) {
      requestUrl += 'importadores=';
      filter.importers.forEach((i, k) => {
        if (k !== 0) {
          requestUrl += '_';
        }
        requestUrl += i;
      });
    }
    if (filter.representatives.length > 0) {
      requestUrl += '&representantes=';
      filter.representatives.forEach((r, i) => {
        if (i !== 0) {
          requestUrl += '_';
        }
        requestUrl += r;
      });
    }
    if (filter.entry_urfs.length > 0) {
      requestUrl += '&urfs_entrada=';
      filter.entry_urfs.forEach((e, i) => {
        if (i !== 0) {
          requestUrl += '_';
        }
        requestUrl += e;
      });
    }
    if (filter.clearance_urfs.length > 0) {
      requestUrl += '&urfs_despacho=';
      filter.clearance_urfs.forEach((c, i) => {
        if (i !== 0) {
          requestUrl += '_';
        }
        requestUrl += c;
      });
    }
    requestUrl += `&data_inicio=${filter.start_date}&data_fim=${
      filter.end_date
    }`;

    return this.httpClient.get<any>(requestUrl, {
      reportProgress: true
    });
  }
}
