import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RepresentativesListComponent } from './representatives-list.component';

describe('RepresentativesListComponent', () => {
  let component: RepresentativesListComponent;
  let fixture: ComponentFixture<RepresentativesListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RepresentativesListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RepresentativesListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
