import { Component, OnInit, Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Filter } from '../../../../../types/filter/filter';
import * as DateManagement from '../../../../utils/date-management';
import { ReportDataService } from '../../../../../app/report-data.service';
import { FilterItem } from './filter-item.type';
import { FilterService } from './services/filter.service';
import { FilterResultService } from './services/filter-result.service';
import { MatDatepickerInputEvent } from '@angular/material';
import { RepresentationsFilter } from '../representations-filter';

@Component({
  selector: 'app-filter',
  templateUrl: './filter.component.html',
  styleUrls: ['./filter.component.scss']
})
export class FilterComponent implements OnInit {
  data: Filter = null;
  loading = true;
  errored = false;

  @Input() current_filtro: FilterItem = {
    importer: {
      cpf_cnpj: '',
      name: ''
    },
    representative: {
      cpf_cnpj: '',
      name: ''
    },
    entryUrf: {
      code: '',
      name: ''
    },
    clearanceUrf: {
      code: '',
      name: ''
    }
  };

  filtro: Filter = {
    data_fim: DateManagement.BrFormatDateFromDate(new Date()),
    data_inicio: DateManagement.BrFormatDateFromDate(new Date()),
    clearance_urfs: [],
    entry_urfs: [],
    importers: [],
    representatives: []
  };

  public minDataInicio: Date;
  public maxDataInicio: Date;
  public minDataFim: Date;
  public maxDataFim: Date;

  @Input('dataInicio')
  get dataInicio(): Date {
    return DateManagement.DateFromBrFormatDate(this.filtro.data_inicio);
  }
  set dataInicio(date: Date) {
    this.filtro.data_inicio = DateManagement.BrFormatDateFromDate(date);
  }

  @Input('dataFim')
  get dataFim(): Date {
    return DateManagement.DateFromBrFormatDate(this.filtro.data_fim);
  }
  set dataFim(date: Date) {
    this.filtro.data_fim = DateManagement.BrFormatDateFromDate(date);
  }
  constructor(
    private dataService: ReportDataService,
    private filterService: FilterService,
    private filterResultService: FilterResultService,
    private router: Router,
    private route: ActivatedRoute
  ) {
    filterResultService.filterResult.subscribe(f => {
      this.filtro = f;
      this.refreshDates();
    });
  }

  public onChangeDate(
    identifier: number,
    event: MatDatepickerInputEvent<Date>
  ) {
    if (identifier === 0) {
      this.filterResultService.changeFilterResult({
        ...this.filtro,
        data_inicio: DateManagement.BrFormatDateFromDate(event.value)
      });
    } else if (identifier === 1) {
      this.filterResultService.changeFilterResult({
        ...this.filtro,
        data_fim: DateManagement.BrFormatDateFromDate(event.value)
      });
    }
  }

  public refreshDates() {
    const dataAtual = new Date();
    const dataMinima = new Date();
    dataMinima.setMonth(dataAtual.getMonth() - 3);

    this.minDataInicio = dataMinima;
    this.maxDataInicio = dataAtual;

    this.minDataFim = this.dataInicio;
    this.maxDataFim = dataAtual;
  }

  public getFilterAsString(): string {
    return JSON.stringify({
      importers: this.filtro.importers.map(i => parseInt(i.id, 10)),
      representatives: this.filtro.representatives.map(r => parseInt(r.id, 10)),
      entry_urfs: this.filtro.entry_urfs.map(eu => eu.id),
      clearance_urfs: this.filtro.clearance_urfs.map(cu => cu.id),
      start_date: this.filtro.data_inicio,
      end_date: this.filtro.data_fim
    } as RepresentationsFilter);
  }

  public generateReport() {
    this.router.navigate([`./result`], {
      relativeTo: this.route,
      replaceUrl: true,
      queryParams: {
        filter: this.getFilterAsString()
      }
    });
  }

  public updateFiltro() {
    this.filterService.changeFilter(this.current_filtro);
  }

  public updateFiltroFinal() {
    this.filterResultService.changeFilterResult(this.filtro);
  }

  public getDataTransformed(data: any): Filter {
    return {
      importers: Object.keys(data.importers)
        .map(key => {
          const importer = data.importers[key];
          return {
            id: key,
            cpf_cnpj: importer.cpf_cnpj,
            name: importer.name
          };
        })
        .sort(a => a.name),
      representatives: Object.keys(data.representatives)
        .map(key => {
          const representative = data.representatives[key];
          return {
            id: key,
            cpf_cnpj: representative.cpf_cnpj,
            name: representative.name
          };
        })
        .sort(a => a.name),
      entry_urfs: Object.keys(data.entry_urfs)
        .map(key => {
          const entryUrf = data.entry_urfs[key];
          return {
            id: parseInt(key, 10),
            code: entryUrf.code,
            name: entryUrf.name
          };
        })
        .sort(a => a.name),
      clearance_urfs: Object.keys(data.clearance_urfs)
        .map(key => {
          const clearanceUrf = data.clearance_urfs[key];
          return {
            id: parseInt(key, 10),
            code: clearanceUrf.code,
            name: clearanceUrf.name
          };
        })
        .sort(a => a.name)
    };
  }

  ngOnInit() {
    this.filterResultService.resetFilter();
    this.dataService.getDadosFiltro().subscribe(
      data => {
        this.data = this.getDataTransformed(data);
        window.sessionStorage.setItem('filter', JSON.stringify(this.data));
        this.loading = false;
      },
      error => {
        this.errored = true;
        //
      }
    );

    this.filterService.clearFilter();
  }
}
