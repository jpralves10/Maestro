import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TrendlineChartComponent } from './trendline-chart.component';

describe('TrendlineChartComponent', () => {
  let component: TrendlineChartComponent;
  let fixture: ComponentFixture<TrendlineChartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TrendlineChartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TrendlineChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
