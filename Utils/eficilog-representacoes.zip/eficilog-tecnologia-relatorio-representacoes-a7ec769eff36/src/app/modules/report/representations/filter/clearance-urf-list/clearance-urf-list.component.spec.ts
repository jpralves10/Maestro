import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClearanceUrfListComponent } from './clearance-urf-list.component';

describe('ClearanceUrfListComponent', () => {
  let component: ClearanceUrfListComponent;
  let fixture: ComponentFixture<ClearanceUrfListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClearanceUrfListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClearanceUrfListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
