export interface RepresentationsFilter {
  importers: number[];
  representatives: number[];
  entry_urfs: number[];
  clearance_urfs: number[];
  start_date: string;
  end_date: string;
}
