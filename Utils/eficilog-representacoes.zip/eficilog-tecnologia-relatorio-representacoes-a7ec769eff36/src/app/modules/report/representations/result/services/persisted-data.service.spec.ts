import { TestBed } from '@angular/core/testing';

import { PersistedDataService } from './persisted-data.service';

describe('PersistedDataService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PersistedDataService = TestBed.get(PersistedDataService);
    expect(service).toBeTruthy();
  });
});
