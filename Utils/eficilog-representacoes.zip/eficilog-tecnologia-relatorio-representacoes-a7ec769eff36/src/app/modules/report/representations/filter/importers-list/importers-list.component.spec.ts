import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImportersListComponent } from './importers-list.component';

describe('ImportersListComponent', () => {
  let component: ImportersListComponent;
  let fixture: ComponentFixture<ImportersListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImportersListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImportersListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
