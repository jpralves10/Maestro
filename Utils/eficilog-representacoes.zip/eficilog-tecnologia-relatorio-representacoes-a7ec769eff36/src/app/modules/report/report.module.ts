import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IndexComponent } from './index/index.component';
import { Routes, RouterModule } from '@angular/router';
import { MaterialModule } from '../../material/material.module';

const reportRoutes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    component: IndexComponent
  },
  {
    path: 'representations',
    loadChildren:
      './representations/representations.module#RepresentationsModule'
  }
];

@NgModule({
  declarations: [IndexComponent],
  imports: [CommonModule, MaterialModule, RouterModule.forChild(reportRoutes)],
  exports: [RouterModule]
})
export class ReportModule {}
