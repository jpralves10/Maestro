import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
// import { ReportModule } from './report/report.module';
import { DashboardComponent } from './dashboard/dashboard.component';
import { Routes, RouterModule } from '@angular/router';
import { MaterialModule } from '../material/material.module';
import { MatPaginatorIntl } from '@angular/material';
import { MatPaginatorIntlPtbr } from './mat-paginator-intl-ptbr';

const mainRoutes: Routes = [
  {
    path: '',
    redirectTo: '/report',
    pathMatch: 'full'
  },
  {
    path: 'report',
    loadChildren: './report/report.module#ReportModule'
  }
];

@NgModule({
  declarations: [DashboardComponent],
  imports: [CommonModule, RouterModule.forRoot(mainRoutes), MaterialModule],
  exports: [RouterModule],
  providers: [
    {
      provide: MatPaginatorIntl,
      useClass: MatPaginatorIntlPtbr
    }
  ]
})
export class ModulesModule {}
