import { TestBed } from '@angular/core/testing';

import { ExportingService } from './exporting.service';

describe('ExportingService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ExportingService = TestBed.get(ExportingService);
    expect(service).toBeTruthy();
  });
});
