import { RepresentacoesData } from './representacoes-data';
import { Importer } from './importer';

export interface ImporterItem {
  my: RepresentacoesData;
  others: RepresentacoesData;
  importer: Importer;
}
