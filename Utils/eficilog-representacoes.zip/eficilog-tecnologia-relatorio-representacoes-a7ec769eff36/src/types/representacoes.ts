import { RepresentacoesData } from './representacoes-data';
import { ImporterList } from './importer-list';
import { RepresentacoesCompartilhadaData } from './representacoes-compartilhadas-data';

export interface Representacoes {
  my: RepresentacoesData;
  both: RepresentacoesCompartilhadaData;
  others: RepresentacoesData;
  importers: ImporterList;
}
