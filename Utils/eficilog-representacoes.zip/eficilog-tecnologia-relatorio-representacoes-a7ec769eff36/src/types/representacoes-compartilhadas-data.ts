import { RepresentacoesData } from './representacoes-data';

export interface RepresentacoesCompartilhadaData {
  quantity: number;
  value: number;
  my: RepresentacoesData;
  others: RepresentacoesData;
}
