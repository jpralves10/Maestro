export interface RepresentacoesData {
  quantity: number;
  value: number;
}
