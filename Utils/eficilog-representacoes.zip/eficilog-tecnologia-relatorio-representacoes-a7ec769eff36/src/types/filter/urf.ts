export interface Urf {
  id: number;
  code: string;
  name: string;
}
