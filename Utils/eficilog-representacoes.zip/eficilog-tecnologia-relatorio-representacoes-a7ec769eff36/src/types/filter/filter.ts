import { Importer } from './importer';
import { Representative } from './representative';
import { Urf } from './urf';

export interface Filter {
  importers: Importer[];
  representatives: Representative[];
  entry_urfs: Urf[];
  clearance_urfs: Urf[];
  data_inicio?: string;
  data_fim?: string;
}
