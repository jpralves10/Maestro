export interface Importer {
  id: string;
  cpf_cnpj: string;
  name: string;
}
