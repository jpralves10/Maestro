export interface Representative {
  id: string;
  cpf_cnpj: string;
  name: string;
}
