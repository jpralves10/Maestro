export enum SelectionChannel {
  '000' = '000',
  '001' = '001',
  '002' = '002',
  '003' = '003',
  '004' = '004'
}

export interface Ncm {
  code: string;
  country: string;
  ncm: string;
}

export interface Declaration {
  representative_id: number;
  discharge_dollar_value: number;
  entry_urf_id: number;
  clearance_urf_id: number;
  ncms: Ncm[];
  number: string;
  registration: string;
  selection_channel: SelectionChannel;
}

export interface Importer {
  id: number;
  my: {
    declarations: Declaration[];
    quantity: number;
    value: number;
  };
  others: {
    declarations: Declaration[];
    quantity: number;
    value: number;
  };
}

export interface Urf {
  id: number;
  my: {
    quantity: number;
    value: number;
  };
  others: {
    quantity: number;
    value: number;
  };
}

export interface Representations {
  my: {
    quantity: number;
    value: number;
  };
  others: {
    quantity: number;
    value: number;
  };
  both: {
    my: {
      quantity: number;
      value: number;
    };
    others: {
      quantity: number;
      value: number;
    };
    quantity: number;
    value: number;
  };
  importers: Importer[];
  clearance_urfs: Urf[];
}
