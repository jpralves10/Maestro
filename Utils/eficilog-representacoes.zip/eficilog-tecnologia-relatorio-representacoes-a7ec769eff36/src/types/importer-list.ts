import { ImporterItem } from './importer-item';

export interface ImporterList {
  [id: number]: ImporterItem;
}
